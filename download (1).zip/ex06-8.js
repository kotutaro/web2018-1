function sayhello68(){
  alert('Hello,' + document.getElementById('who').innerHTML + '!');
}
function taro(){
  document.getElementById('who').innerHTML = '太郎';
}
function hanako(){
  document.getElementById('who').innerHTML = '花子';
}
