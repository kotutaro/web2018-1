function sayhello(){
  var who = 'world';
  alert('Hello,' + who + '!');
}
function taro(){
  who = '太郎';
}
function hanako(){
  who = '花子';
}
