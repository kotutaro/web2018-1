var who = 'world';
function sayhello(){
  alert('Hello,' + who +'!');
}
function someone(x){
  who = x;
}
