//function sayhello(){alert('Hello,Function!');}
function saygoodbye(){alert('Goodbye!');}